/* (WiFi) Variables */
char ssid[] = "MyWifi2G"; // Your WiFi credentials.
char pass[] = "31133985"; // Set password to "" for open networks.

const char* UName = "cc";
const char* PassW = "1234";
